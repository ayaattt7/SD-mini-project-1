# Ayatul Hakim — Personal Profile Page

## Structure
```
ayatul-profile/
├── index.html
├── style.css
└── images/
    └── profile.jpg
```

## Deploy with GitHub Pages
1. Create a new GitHub repository and push these files/folders to it.
2. Go to **Settings → Pages** on GitHub.
3. Under "Build and deployment," set Source to **Deploy from a branch**, pick `main` and `/ (root)`, then Save.
4. GitHub gives you a live URL in a minute or two (usually `https://<username>.github.io/<repo-name>/`).

## Submission
- GitHub repository link
- Live site link (from Pages)
